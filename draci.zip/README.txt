Vaideanu Renata - Georgia - 332 CD

./app:
/task_runner.py contains:
- Task class - represents an individual task that can be submitted to a task queue for processing.
        It encapsulates all the necessary information required to execute the task effectively.
        (I added a variable is_unittesting for the unittest case, that field is unused in any other
        case, being replaced with False)
- ThreadPool class - manages a pool of threads for executing tasks concurrently.
        - __init__ - initializes several attributes
            tsk_queue: A queue to hold tasks waiting to be processed;
            thr_list: A list to keep track of the threads created for task execution;
            jobs: A dictionary to maintain the status of each task.
            shutdown_flag: A flag to indicate whether the thread pool is being shut down.
        - submit_task - adds the new task to the task queue and updates the jobs dictionary to 
            track the status of the submitted task.
        - start - starts multiple threads based on the specified number of threads in the
            environment. Each thread is an instance of the TaskRunner class, which is responsible 
            for fetching tasks from the queue and executing them.
        - graceful_shutdown - signals all TaskRunner threads to gracefully shut down. It iterates
            through the list of threads and invokes a shutdown method on each thread. Then, it 
            waits for all threads to finish their execution by calling the join method on each 
            thread.
- TaskRunner class - manages the tasks that would be used in the process 
    (In the code there is a docscript for each and every one of the request functions)
        - __init__ - initializes several attributes
            tsk_queue - A queue to hold tasks waiting to be processed;
            jobs - A dictionary for the tasks' statuses, running if it's execusion is not done yet
                or done if it's finished
            shutdown_flag - the flag for shutdown that is used for the /api/graceful_shutdown 
                calling
        - run -  function that runs through all the tasks and executes them 
        - execute_task - function that goes through all the urls and based on that, tests the 
            allocated test

/routes.py contains one function for each and every request that is called to the server.
